﻿
=====================================================================
                  XML schéma pro výměnu faktur ISDOC
=====================================================================

                        Verze 5.1 z 10.3.2009

       (c) 2009 Sdružení pro informační společnost, www.spis.cz

=====================================================================

Přiložená schémata formálně definují výměnný formát faktur definovaný 
Pracovní skupinou elektronické standardy výměny dat sdružení SPIS.

Obsah distribuce:
-----------------

xsd/*   - schémata v jazyce W3C XML Schema

          isdoc-invoice-5.1.xsd       - základní schéma

          isdoc-invoice-5.1-dsig.xsd  - schéma validující i stukturu 
                                        vloženého digitálního podpisu

          xmldsig-core-schema.xsd     - schéma XML Signature                                    

doc/*   - hypertextová dokumentace W3C XML Schematu


Poznámka:
---------

Použijte schéma isdoc-invoice-5.1.xsd pokud si budete přát validovat pouze 
samotnou fakturu bez elektronického podpisu. V případě validace vč. podpisu
použijte schéma isdoc-invoice-5.1-dsig.xsd, které pomocí příkazů import a 
redefine automaticky použije i obě další schémata.

Omezení schémat:
----------------

Ve verzi 5.1 nedefinuje schéma přiliš striktní kontroly, popisuje
pouze základní strukturu faktury a datové typy. Je pravděpodobné, že
v budoucnu bude schéma vylepšeno tak, aby provádělo důslednější
kontroly dat.

Kontakt: info@isdoc.cz, www.isdoc.cz